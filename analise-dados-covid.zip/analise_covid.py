import pandas as pd
import matplotlib.pyplot as plt

# Carregar os dados
df = pd.read_csv('dados/covid.csv')

# Exibir as primeiras linhas
print("Prévia dos dados:")
print(df.head())

# Plotar gráfico de evolução de casos
plt.figure(figsize=(10, 6))
plt.plot(pd.to_datetime(df["Data"]), df["Casos"], marker='o', label='Casos')
plt.title("Evolução dos Casos de COVID-19")
plt.xlabel("Data")
plt.ylabel("Número de Casos")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.savefig("imagens/grafico_casos.png")
plt.show()
