# Análise de Dados COVID-19 📊

Este projeto faz uma análise simples da evolução dos casos de COVID-19 usando Python e bibliotecas como Pandas e Matplotlib.

## Objetivos

- Carregar um conjunto de dados CSV
- Visualizar a evolução de casos ao longo do tempo
- Gerar um gráfico ilustrativo

## Como executar

1. Certifique-se de ter Python instalado
2. Execute `pip install pandas matplotlib`
3. Rode o script: `python analise_covid.py`

## Autor

Elias Rodrigues – Estudante de Sistemas para Internet | 2º período
